# A1 Performance Engine 0.2.0

An original Quest 3S companion utility that prepares ADB commands for supported display/render overrides and diagnostics.

## Important CPU/GPU limitation
Meta's current Horizon OS documentation says the `debug.oculus.cpuLevel` and `debug.oculus.gpuLevel` pin properties are for development profiling only and explicitly says never to use them in a shipped app. This project intentionally does not automate those clock pins. It includes a command to enable clock-state diagnostic logging.

Official references:
- https://developers.meta.com/vr/documentation/native/android/os-cpu-gpu-levels/
- https://developers.meta.com/vr/documentation/spatial-sdk/os-cpu-gpu-levels/
- https://developers.meta.com/vr/documentation/native/android/ts-systemproperties/

## What the app does
- Copies preset ADB commands for texture width, texture height, and refresh rate.
- Presets: Balanced, Performance, Quality, High Refresh.
- Copies reset commands to clear those overrides.
- Copies a CPU/GPU clock-state diagnostic command.
- Does not execute ADB commands itself; paste them into the ADB shell you already use.
- Does not root, overclock, bypass thermal protections, or modify game files.

Quest 3S supports 72, 80, 90, and 120 Hz. Texture override behavior can vary by OS version and game. A higher refresh rate or resolution can reduce performance in demanding games. Changes are temporary and may reset on reboot.

## Build APK using GitHub Actions (no computer required if using Quest browser)
1. Create a GitHub repository.
2. Upload the contents of this project, preserving the `.github/workflows/android.yml` path.
3. Commit to the `main` branch.
4. Open the repository's Actions tab. Allow GitHub Actions if prompted.
5. Open the workflow run named "Build A1 Performance Engine APK".
6. When it succeeds, scroll to Artifacts and download `A1-Performance-Engine-debug-apk`.
7. Extract the artifact ZIP; install `app-debug.apk` on the Quest 3S.

This produces a debug-signed APK suitable for personal testing, not a Play Store release.

## Package
`com.a1brave.performanceengine`
