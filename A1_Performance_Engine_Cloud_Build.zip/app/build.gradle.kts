plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.a1brave.performanceengine"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.a1brave.performanceengine"
        minSdk = 29
        targetSdk = 32
        versionCode = 2
        versionName = "0.2.0"
    }
}
