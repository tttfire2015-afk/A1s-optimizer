package com.a1brave.performanceengine

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.view.View

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 8, 13)
    private val panel = Color.rgb(27, 15, 23)
    private val red = Color.rgb(255, 35, 86)
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(text("A1 PERFORMANCE ENGINE", 25, red, true))
        page.addView(text("QUEST 3S  •  ADB PERFORMANCE TOOLKIT", 11, Color.LTGRAY, true).apply {
            setPadding(0, dp(5), 0, dp(18))
        })
        page.addView(card(text(
            "This version prepares supported Quest system-property commands and copies them for you. It does not secretly run shell commands or claim to overclock the headset.",
            13, Color.LTGRAY, false
        )))
        page.addView(section("PROFILE PRESETS"))
        addProfile(page, "BALANCED", "1440", "1512", "90",
            "Balanced resolution and 90 Hz refresh target.")
        addProfile(page, "PERFORMANCE", "1260", "1320", "72",
            "Lower render dimensions and 72 Hz to reduce GPU workload.")
        addProfile(page, "QUALITY", "1680", "1760", "90",
            "Quest 3S default texture dimensions and 90 Hz.")
        addProfile(page, "HIGH REFRESH", "1440", "1512", "120",
            "120 Hz target; supported by Quest 3S, but demanding for games.")
        page.addView(section("RESET OVERRIDES"))
        val reset = button("COPY RESET COMMANDS")
        reset.setOnClickListener {
            copyCommands(
                "adb shell setprop debug.oculus.textureWidth \"\"\n" +
                "adb shell setprop debug.oculus.textureHeight \"\"\n" +
                "adb shell setprop debug.oculus.refreshRate \"\""
            )
        }
        page.addView(reset)

        page.addView(section("CPU / GPU DIAGNOSTICS"))
        page.addView(card(text(
            "Meta documents CPU/GPU level pinning as a development profiling feature only and explicitly says not to use it in a shipped app. This toolkit therefore does not automate CPU/GPU clock pinning. You can inspect performance using Meta's OVR Metrics Tool or developer logcat diagnostics.",
            13, Color.LTGRAY, false
        )))
        val diag = button("COPY CPU/GPU DIAGNOSTIC COMMAND")
        diag.setOnClickListener {
            copyCommands("adb shell setprop debug.oculus.clockStateLogLevel 1")
        }
        page.addView(diag)

        page.addView(section("COMMAND OUTPUT"))
        output = text("Choose a profile to prepare its ADB commands.", 12, Color.WHITE, false)
        page.addView(card(output))
        val copy = button("COPY OUTPUT")
        copy.setOnClickListener { copyCommands(output.text.toString()) }
        page.addView(copy)

        page.addView(section("HOW TO APPLY"))
        page.addView(card(text(
            "1. Tap a profile.\n2. Tap COPY PROFILE COMMANDS.\n3. Paste the commands into your trusted ADB shell connected to the Quest 3S.\n4. Run them. Overrides are temporary and may reset after a reboot.\n\nIf a command is rejected, stop rather than trying random system commands.",
            13, Color.LTGRAY, false
        )))
        page.addView(text(
            "A1 PE 0.2.0  •  Original community project",
            10, Color.GRAY, false
        ).apply { setPadding(0, dp(18), 0, 0) }
    }

    private fun addProfile(parent: LinearLayout, name: String, w: String, h: String, hz: String, note: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(10))
            setBackgroundColor(panel)
        }
        box.addView(text(name, 15, red, true))
        box.addView(text(note, 12, Color.LTGRAY, false).apply { setPadding(0, dp(4), 0, dp(8)) })
        val b = button("COPY $name COMMANDS")
        b.setOnClickListener {
            val commands =
                "adb shell setprop debug.oculus.textureWidth $w\n" +
                "adb shell setprop debug.oculus.textureHeight $h\n" +
                "adb shell setprop debug.oculus.refreshRate $hz"
            output.text = commands
            copyCommands(commands)
        }
        box.addView(b)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        box.layoutParams = lp
        parent.addView(box)
    }

    private fun copyCommands(commands: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("A1 Quest ADB commands", commands))
        Toast.makeText(this, "Commands copied. Paste into your ADB shell.", Toast.LENGTH_LONG).show()
    }

    private fun section(s: String) = text(s, 13, red, true).apply {
        setPadding(0, dp(18), 0, dp(9))
    }

    private fun card(v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(13), dp(12), dp(13), dp(12))
        setBackgroundColor(panel)
        addView(v)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        layoutParams = lp
    }

    private fun button(s: String) = Button(this).apply {
        text = s
        textSize = 11f
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(115, 14, 45))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(2)
        layoutParams = lp
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
